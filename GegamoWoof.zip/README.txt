This application is owned by Gegamo and has advanced Anti-Decompilation techniques.
If you have any software that might tamper with Gegamo Security, Do not run them.

If you tamper with Gegamo Security you may risk getting a BSOD or if done multiple times system32 will be deleted.

At Gegamo we do not authorize any tampering with our software.


Thank you, https://gegamo.xyz